<?php

	
$servername = "localhost";
$username = "root";
$password = "";
$dbname= "db_financial";


echo $_POST["Apellido"];     
echo "\n";
echo $_POST["Teléfono"];
echo "\n";
echo $_POST["Monto_en_Soles"];
echo "\n";
echo $_POST["Nombre"];
echo "\n";
echo $_POST["Email"];
echo "\n";


$name = $_POST["Nombre"];
$email = $_POST["Email"];
$ape =  $_POST["Apellido"];     
$tele = $_POST["Teléfono"];
$monto = $_POST["Monto_en_Soles"];

$plazo = $_POST["Plazo"];
$distrito = $_POST["Distrito"];
$garantía = $_POST["Garantía_de_Propided"];


 $conn = new mysqli($servername, $username, $password,$dbname);
 // Check connection
 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
 }
 
 $sql = "INSERT INTO user ( Email,Nombre,Monto_en_Soles,  Apellido, Teléfono, Plazo , Distrito , Garantía_de_Propided) VALUES  ('.$email.', '.$name.', '.$monto.','.$ape.','.$tele.','.$plazo.','.$distrito.','.$garantía.')";
 
 if ($conn->query($sql) === TRUE) {
     echo "true";
 } else {
     echo "false";

 }
 
 $conn->close();



?>