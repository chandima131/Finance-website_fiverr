$(function() {
  $("#userform input,#userform select").jqBootstrapValidation({
    preventSubmit: true,
    submitError: function($form, event, errors) {
      // additional error messages or events
    },
    submitSuccess: function($form, event) {
      event.preventDefault(); // prevent default submit behaviour
      // get values from FORM
      var name = $("input#username").val();
      var email = $("input#useremail").val();
      var state = $("select#userstate").val();
      var userMonto_en_Soles = $("input#userMonto_en_Soles").val();
      var userApellido = $("input#userApellido").val();
      var userTeléfono = $("input#userTeléfono").val();
      var userGarantía_de_Propided = $("select#userGarantía_de_Propided").val();
      var userPlazo = $("select#userPlazo").val();
      // For Success/Failure Message
      // Check for white space in name for Success/Fail message
      // if (firstName.indexOf(" ") >= 0) {
      //   firstName = name
      //     .split(" ")
      //     .slice(0, -1)
      //     .join(" ");
      // }
      $this = $("#senduserButton");
      $this.prop("disabled", true);
      console.log(name);
      console.log(state);
      console.log(userGarantía_de_Propided);
      //Disable submit button until AJAX call is complete to prevent duplicate messages
      $.ajax({
        url: "../model/db_finance_con.php",
        type: "POST",
        data: {
          Nombre: name,
          Email: email,
          Apellido: userApellido,
          Teléfono: userTeléfono,
          Monto_en_Soles: userMonto_en_Soles,
          Plazo: userPlazo,
          Distrito: state,
          Garantía_de_Propided: userGarantía_de_Propided
        },
        cache: false,
        success: function() {
          // Success message
          $("#successuserfinance").html("<div class='alert alert-success'>");
          $("#successuserfinance > .alert-success")
            .html(
              "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;"
            )
            .append("</button>");
          $("#successuserfinance > .alert-success").append(
            "<strong>Your message has been sent. </strong>"
          );
          $("#successuserfinance > .alert-success").append("</div>");
          //clear all fields
          // $("#userform").trigger("reset");
        },
        error: function() {
          // Fail message
          $("#successuserfinance").html("<div class='alert alert-danger'>");
          $("#successuserfinance > .alert-danger")
            .html(
              "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;"
            )
            .append("</button>");
          $("#successuserfinance > .alert-danger").append(
            $("<strong>").text(
              "Sorry " +
                firstName +
                ", it seems that my mail server is not responding. Please try again later!"
            )
          );
          $("#successuserfinance > .alert-danger").append("</div>");
          //clear all fields
          // $("#userform").trigger("reset");
        },
        complete: function() {
          setTimeout(function() {
            $this.prop("disabled", false); // Re-enable submit button when AJAX call is complete
          }, 1000);
        }
      });
    },
    filter: function() {
      return $(this).is(":visible");
    }
  });

  $('a[data-toggle="tab"]').click(function(e) {
    e.preventDefault();
    $(this).tab("show");
  });
});

/*When clicking on Full hide fail/success boxes */
$("#username").focus(function() {
  $("#success").html("");
});
